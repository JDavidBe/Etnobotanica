<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>@yield('title', 'Panel Admin') — Etnobotánica</title>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;0,700;1,400&family=Nunito:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  @vite(['resources/css/app.css'])
  @stack('styles')
</head>
<body class="admin-body-bg">

<div id="toast" class="toast"><i class="fas fa-check-circle"></i><span id="toast-txt"></span></div>

<div class="admin-wrap">
  @include('components.sidebar')

  <div class="admin-main">
    <div class="admin-bar">
      <h1 id="admin-tit">@yield('admin-title', 'Dashboard')</h1>
      <div style="display:flex;align-items:center;gap:14px">
        <a href="{{ route('home') }}" class="btn-site"><i class="fas fa-eye"></i> Ver sitio</a>
        <span style="font-size:.83rem;color:var(--texto-suave)">👤 {{ auth()->user()->name }}</span>
        <form method="POST" action="{{ route('logout') }}" style="margin:0">
          @csrf
          <button type="submit" class="btn-logout"><i class="fas fa-sign-out-alt"></i></button>
        </form>
      </div>
    </div>

    <div class="admin-body">
      @yield('content')
    </div>
  </div>
</div>

@vite(['resources/js/app.js'])
@stack('scripts')

</body>
</html>
