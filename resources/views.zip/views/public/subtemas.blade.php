@extends('layouts.app')

@section('title', $categoria->nombre . ' — Etnobotánica')


@section('breadcrumbs')
  <i class="fas fa-chevron-right sep"></i>
  <span class="crumb">{{ $categoria->nombre }}</span>
@endsection

@section('content')

<div class="container">
  <div class="sec-inner">
    <a href="{{ route('home') }}" class="back-link">
      <i class="fas fa-arrow-left"></i> Volver a categorías
    </a>
    <p class="sec-titulo">{{ $categoria->nombre }}</p>
    <p class="sec-sub">{{ $categoria->descripcion }}</p>

    <div class="grid-subs">
      @forelse($categoria->subtemas as $sub)
        <a href="{{ route('subtemas.show', [$categoria->id, $sub->id]) }}" class="card-sub">
          <i class="fas fa-leaf"></i>
          <h4>{{ $sub->nombre }}</h4>
          <span>{{ $sub->plantas_count }} plantas</span>
        </a>
      @empty
        <div class="empty">
          <i class="fas fa-folder-open"></i>
          <p>No hay subtemas registrados en esta categoría.</p>
        </div>
      @endforelse
    </div>
  </div>
</div>

@endsection
