@extends('layouts.app')

@section('title', 'Etnobotánica Fusagasugá')


@section('content')

<div class="hero">
  <h1>Saberes botánicos de<br><em>Fusagasugá</em></h1>
  <p>Catálogo colaborativo del conocimiento tradicional sobre plantas medicinales y su uso local.</p>
</div>

<div class="container">
  <div class="sec-inner">
    <p class="sec-titulo">Explorar Categorías</p>
    <p class="sec-sub">Selecciona una categoría para explorar los saberes botánicos</p>

    <div class="grid-cats">
      @forelse($categorias as $cat)
        <a href="{{ route('categorias.show', $cat->id) }}" class="card-cat">
          <div class="cat-ico">
            <i class="{{ $cat->icono }}"></i>
          </div>
          <h3>{{ $cat->nombre }}</h3>
          <p>{{ $cat->descripcion }}</p>
        </a>
      @empty
        <div class="empty">
          <i class="fas fa-seedling"></i>
          <p>No hay categorías registradas aún.</p>
        </div>
      @endforelse
    </div>
  </div>
</div>

@endsection
